function showAnimation(sectionId, duration) {
    var section = document.getElementById(sectionId);
    if (section) {
        var targetPosition = section.getBoundingClientRect().top + window.pageYOffset;
        var startPosition = window.pageYOffset;
        var distance = targetPosition - startPosition;
        var startTime = performance.now();

        function ease(t) {
            return t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
        }

        function scrollAnimation(currentTime) {
            var elapsedTime = currentTime - startTime;
            window.scrollTo(0, ease(elapsedTime / duration) * distance + startPosition);
            if (elapsedTime < duration) {
                requestAnimationFrame(scrollAnimation);
            }
        }

        requestAnimationFrame(scrollAnimation);
    }
}
